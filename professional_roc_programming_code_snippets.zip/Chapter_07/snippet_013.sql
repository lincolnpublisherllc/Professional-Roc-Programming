insert db "users" {"name": "Alice", "email": "alice@example.com"}
