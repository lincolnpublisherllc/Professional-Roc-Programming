result = query connection "SELECT id, name FROM users WHERE active = true"
