# Step 2: Enable LSP for Roc
# In settings.json:
"roc.languageServer.enabled": true
