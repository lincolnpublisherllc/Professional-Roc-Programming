Actor-Based Architecture: Actors ensured that each inventory update was processed sequentially, reducing errors during high-concurrency events.
