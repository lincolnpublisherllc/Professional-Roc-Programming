# Safe to read concurrently without locks
