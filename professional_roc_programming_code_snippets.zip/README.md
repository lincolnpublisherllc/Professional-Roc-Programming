# Professional Roc Programming — Extracted Code Snippets

This archive contains code snippets extracted chapter-by-chapter from the provided manuscript.

## Structure
Each chapter appears as a folder inside `roc_code/` with files named `snippet_###`.
File extensions are best-effort guesses based on content (e.g., `.roc`, `.sh`, `.yml`, `.sql`, `.graphql`, `.txt`).

## Chapter Summary
- Introduction: 14 snippet(s)
- Chapter_01: 16 snippet(s)
- Chapter_02: 23 snippet(s)
- Chapter_03: 17 snippet(s)
- Chapter_04: 24 snippet(s)
- Chapter_05: 28 snippet(s)
- Chapter_06: 32 snippet(s)
- Chapter_07: 33 snippet(s)
- Chapter_08: 21 snippet(s)
- Chapter_09: 18 snippet(s)
- Chapter_10: 12 snippet(s)
- Chapter_11: 36 snippet(s)
- Chapter_12: 29 snippet(s)
- Chapter_13: 20 snippet(s)
- Chapter_14: 9 snippet(s)
- Chapter_15: 19 snippet(s)

**Total snippets:** 351

> Note: Detection is heuristic. If you spot anything missing or misclassified, let me know and I can refine the rules.
