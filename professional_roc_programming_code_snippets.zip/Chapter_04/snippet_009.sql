insert : Ord a => a -> Heap a -> Heap a
