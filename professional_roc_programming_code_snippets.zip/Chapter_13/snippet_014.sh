# | add takes two integers and returns their sum.
add : Int -> Int -> Int
